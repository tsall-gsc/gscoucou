-- =====================================================================
-- Assign each teacher to their class for the current school year.
-- Adds any teacher that is missing, matching on first name, last name and phone.
-- Run in Supabase: SQL Editor -> New query -> paste -> Run
-- Requirements: the teachers table uses first_name/last_name
--               (run fix_teachers_table.sql first if unsure),
--               and one school year is marked "current" in the app.
-- Safe to run twice: nothing is duplicated.
-- =====================================================================

-- 1) Make sure every grade exists. Existing grades are left untouched.
--    sort_order controls the display order (6A first, PSB last); change it later in the app.
insert into public.grades (name, sort_order) values
  ('6A', 1), ('5A', 2), ('4A', 3), ('3A', 4), ('2A', 5),
  ('1A', 6), ('GSA', 7), ('MSA', 8), ('PSA', 9), ('PSB', 10)
on conflict (name) do nothing;

-- 2) Add each teacher if missing, then assign them to their grade.
do $$
declare
  r   record;
  tid bigint;
  yid bigint;
begin
  select id into yid from public.school_years where is_current limit 1;
  if yid is null then
    raise exception 'No current school year. Add one in the app and click "Make current", then run this again.';
  end if;

  for r in
    select * from (values
      ('Mamadou Aissatou', 'Diallo',  '6A',  '629-88-04-32'),
      ('Djiba',            'Mansare', '5A',  '622-73-44-75'),
      ('Aissatou',         'Diallo',  '4A',  '610-55-68-76'),
      ('Yoro',             'Sidibe',  '3A',  '610-04-08-90'),
      ('Mariame',          'Soumah',  '2A',  '629-34-47-26'),
      ('Maladho',          'Kante',   '1A',  '627-36-98-89'),
      ('Mariame Cire',     'Cisse',   'GSA', '622-91-43-63'),
      ('Hawa',             'Konate',  'MSA', '613-02-56-61'),
      ('Fatoumata',        'Bah',     'PSA', '620-34-72-96'),
      ('Fatoumata',        'Fofana',  'PSB', '622-00-00-00')
    ) as t(first_name, last_name, grade, phone)
  loop
    select id into tid
    from public.teachers
    where first_name = r.first_name and last_name = r.last_name and phone = r.phone
    limit 1;

    if tid is null then
      insert into public.teachers (first_name, last_name, phone)
      values (r.first_name, r.last_name, r.phone)
      returning id into tid;
    end if;

    insert into public.teacher_assignments (teacher_id, grade_id, school_year_id)
    select tid, g.id, yid
    from public.grades g
    where g.name = r.grade
    on conflict do nothing;
  end loop;
end $$;

-- 3) Check: each grade with its teacher for the current year.
select g.name as grade, t.first_name, t.last_name, t.phone
from public.teacher_assignments a
join public.teachers t     on t.id = a.teacher_id
join public.grades g       on g.id = a.grade_id
join public.school_years y on y.id = a.school_year_id and y.is_current
order by g.sort_order, t.last_name, t.first_name;
